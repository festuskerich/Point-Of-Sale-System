<?php

return [
    'name' => 'Repair',
    'module_version' => "0.9",
    'pid' => 6
];
