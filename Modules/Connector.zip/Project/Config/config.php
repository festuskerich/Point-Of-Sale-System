<?php

return [
    'name' => 'Project',
    'module_version' => "1.6",
    'pid' => 5
];
