<?php

return [
    'name' => 'Crm',
    'module_version' => "1.0",
    'pid' => 7
];
