<?php
return [
    'connector_module' => 'Mpesa Till/Paybill/Bulk SMS',
    'connector' => 'Mpesa Till/Paybill/Bulk SMS',
    'create_client' => 'Create Client',
    'client_secret' => 'Client secret',
    'clients' => 'Clients',
    'documentation' => 'Documentation',
    'regenerate_doc' => 'Regenerate'
];