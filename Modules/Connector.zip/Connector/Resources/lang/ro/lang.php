<?php
return [
	"connector_module"=>"Modul conector",
	"connector"=>"Conector",
	"create_client"=>"Creați client",
	"client_secret"=>"Secretul clientului",
	"clients"=>"Clienți",
	"documentation"=>"Documentație",
];