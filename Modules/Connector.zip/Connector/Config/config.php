<?php

return [
    'name' => 'Connector',
    'module_version' => "0.9",
    'pid' => 9
];
