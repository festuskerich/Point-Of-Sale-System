<?php

return [
    'name' => 'Manufacturing',
    'module_version' => '2.1',
    'pid' => 4
];
